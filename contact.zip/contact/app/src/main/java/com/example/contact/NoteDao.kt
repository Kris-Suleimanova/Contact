package com.example.contact

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update


@Dao
interface NoteDao {

    @Query("SELECT * FROM notes")
    suspend fun getAl(): List<Note>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun intAll(notes: List<Note>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inNote(note: Note): Long

    @Update
    suspend fun upNote(note: Note)

    @Delete
    suspend fun delNote(note: Note)

    @Query("SELECT * FROM notes WHERE contactId = :contactId")
    suspend fun getContactId(contactId: Long) : Note?


    @Query("SELECT id FROM notes WHERE contactId =:contactId")
    suspend fun getCont(contactId: Long): Long?


}