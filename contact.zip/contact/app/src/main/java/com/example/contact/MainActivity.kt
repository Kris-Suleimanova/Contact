package com.example.contact

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

import com.example.contact.ui.theme.ContactTheme

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults

import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope

import kotlinx.coroutines.launch



class MainActivity : ComponentActivity() {

    private lateinit var contactRepository: ContactRepository
    private lateinit var noteRepository: NoteRepository

    private var contacts by mutableStateOf(emptyList<Contact>())
    private var notes by mutableStateOf(emptyList<Note>())

    private var selectedContactId by mutableStateOf(0L)
    private var isEditDialogVisible by mutableStateOf(false)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        contactRepository = ContactRepository(this)
        noteRepository = NoteRepository(this)

        importContacts()
        importNotes()

        setContent {
            ContactTheme(content = {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFCCC2DC)
                ) {
                    Cont(context = this)
                }
            }
            )
        }
        // Check and request contacts permission at runtime
        checkAndRequestContactsPermission()
    }

    private var isContactsImported by mutableStateOf(false)
    private var isNotesImported by mutableStateOf(false)


    private fun importContacts() {
        if (!isContactsImported) {
            lifecycleScope.launch {
                contactRepository.impCont()
                contacts = contactRepository.getAllContacts()
            }
            isContactsImported = true
        }
    }

    private fun importNotes(){
        if(!isNotesImported){
            lifecycleScope.launch {
                notes = noteRepository.getAllNotes()
            }
            isNotesImported = true;
        }
    }

    private val READ_CONTACTS_PERMISSION_REQUEST_CODE = 1001
    private val WRITE_CONTACTS_PERMISSION_REQUEST_CODE = 1002

    private fun checkAndRequestContactsPermission() {
        // Check if the READ_CONTACTS permission is granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request the READ_CONTACTS permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                READ_CONTACTS_PERMISSION_REQUEST_CODE
            )
        } else {
            // Check if the WRITE_CONTACTS permission is granted
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_CONTACTS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Request the WRITE_CONTACTS permission
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_CONTACTS),
                    WRITE_CONTACTS_PERMISSION_REQUEST_CODE
                )
            } else {
                // Both permissions are granted, proceed with accessing the contacts provider
                importContacts()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            READ_CONTACTS_PERMISSION_REQUEST_CODE,
            WRITE_CONTACTS_PERMISSION_REQUEST_CODE -> {
                // Check if the permission is granted
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, proceed with accessing the contacts provider
                    importContacts()
                } else {
                    // Permission denied, handle accordingly (e.g., show a message to the user)
                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }
    }


    @Composable
    private fun Cont(context: Context) {
        Text(
            text = "Контакты",
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            fontFamily= FontFamily.Serif,
            color = Color.Blue,
            fontStyle = FontStyle.Italic,
            textDecoration = TextDecoration.Underline,
            fontSize=35.sp
        )
        Column {
            LazyColumn(
                modifier = Modifier
                    .padding(20.dp)
                    .weight(2f) // Use weight to allow LazyColumn to take the remaining space
            ) {
                item {
                    // This is a placeholder item that acts as a spacer
                    Spacer(modifier = Modifier.height(60.dp))
                }
                items(contacts.size) { index ->
                    val contact = contacts[index]
                    val note = notes.find { note -> note.contactId == contact.id }
                    Contact(
                        cont = contact,
                        n = note,
                        onEdit = {
                            selectedContactId = contact.id
                            isEditDialogVisible = true
                        },
                        onDelete = {
                            lifecycleScope.launch {
                                val note = noteRepository.getNoteByContactId(contact.id)
                                if(note != null){
                                    noteRepository.deleteNote(note)
                                }
                                notes=noteRepository.getAllNotes()
                            }
                        }
                    )
                }
            }

            if (isEditDialogVisible) {
                val note = notes.find { note -> note.contactId == selectedContactId }
                EditContactDialog(
                    old = note?.description ?: "ничего",
                    onDis = {
                        isEditDialogVisible = false
                    },
                    save = { newNote: String ->
                        lifecycleScope.launch {
                            val idNote = noteRepository.getNoteIdByContactId(selectedContactId)
                            if(idNote != null){
                                val editedNote = Note(
                                    id = idNote,
                                    description = newNote,
                                    contactId = selectedContactId
                                )
                                noteRepository.updateNote(editedNote)
                            }
                            else{
                                val note = Note(
                                    description = newNote,
                                    contactId = selectedContactId
                                )
                                noteRepository.insertNote(note)
                            }
                            notes = noteRepository.getAllNotes();
                        }
                        isEditDialogVisible = false
                    }
                )
            }
        }
    }


    @Composable
    private fun Contact(
        cont: Contact,
        n: Note?,
        onEdit: () -> Unit,
        onDelete: () -> Unit
    ) {

        val desc: String = n?.description ?: stringResource(R.string.empty_note_text)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(
                text = "Имя: ${cont.name}\nТелефон: ${cont.phoneNumber}\nЗаметки: ${desc}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                fontFamily= FontFamily.Serif,
                color = Color.Blue,
                fontStyle = FontStyle.Italic,
                fontSize=25.sp
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 15.dp),
                horizontalArrangement = Arrangement.End
            ) {
                ContactActionButton(Icons.Default.Edit) {
                    onEdit()
                }
                ContactActionButton(Icons.Default.Delete) {
                    onDelete()
                }
            }
            Divider(modifier = Modifier.padding(vertical = 10.dp))
        }
    }


    @Composable
    private fun ContactActionButton(icon: ImageVector, onClick: () -> Unit) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(50.dp),
            colors = IconButtonDefaults.iconButtonColors( containerColor=Color.Gray,contentColor = Color.Red, disabledContainerColor= Color.DarkGray)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground
            )
        }
    }


    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun EditContactDialog(
        old: String,
        onDis: () -> Unit,
        save: (newNote: String) -> Unit

    ) {
        var newNote by remember { mutableStateOf(TextFieldValue(old)) }

        AlertDialog(
            onDismissRequest = { onDis() },
            title = { Text(stringResource(R.string.edit_note_dialog_label),
                fontWeight = FontWeight.Bold,
                fontFamily= FontFamily.Serif,
                color = Color.Blue,
                fontStyle = FontStyle.Italic,
                fontSize=25.sp) },
            text = {
                Column {
                    TextField(
                        colors = TextFieldDefaults.textFieldColors( Color(0xFFC04646), Color.Magenta, cursorColor = Color.Blue),
                        value = newNote,
                        onValueChange = { newNote = it },
                       
                        label = { Text(stringResource(R.string.new_note_dialog_label),
                            fontWeight = FontWeight.Bold,
                            fontFamily= FontFamily.Serif,
                            color = Color.Blue,
                            fontStyle = FontStyle.Italic,
                            fontSize=25.sp) }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        save(newNote.text)
                        onDis()
                    },
                    shape = CircleShape,
                    border = BorderStroke(5.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                    Text(stringResource(R.string.save_btn_label),
                        fontWeight = FontWeight.Bold,
                        fontFamily= FontFamily.Serif,
                        color = Color.Black,
                        fontStyle = FontStyle.Italic,
                        fontSize=25.sp)
                }
            },
            dismissButton = {
                Button(
                    onClick = { onDis() },
                    shape = CircleShape,
                    border = BorderStroke(5.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                    Text(stringResource(R.string.cancel_btn_label),
                        fontWeight = FontWeight.Bold,
                        fontFamily= FontFamily.Serif,
                        color = Color.Black,
                        fontStyle = FontStyle.Italic,
                        fontSize=25.sp)
                }
            }
        )
    }
}