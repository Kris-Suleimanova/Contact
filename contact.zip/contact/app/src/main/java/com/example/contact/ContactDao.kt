package com.example.contact

import androidx.room.*

@Dao
interface ContactDao {

    @Query("SELECT * FROM contacts")
    suspend fun allCont(): List<Contact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(contacts: List<Contact>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inCont(contact: Contact): Long

    @Update
    suspend fun upCont(contact: Contact)

    @Delete
    suspend fun delCont(contact: Contact)
}