package com.example.contact

import android.content.Context
class NoteRepository(context: Context) {

    private val noteDao: NoteDao = AppDatabase.getDatabase(context).noteDao()


    suspend fun getAllNotes(): List<Note> {
        return noteDao.getAl();
    }

    suspend fun insertAll(notes: List<Note>) {
        return noteDao.intAll(notes);
    }

    suspend fun insertNote(note: Note): Long {
        return noteDao.inNote(note)
    }

    suspend fun updateNote(note: Note){
        return noteDao.upNote(note)
    }

    suspend fun deleteNote(note: Note){
        return noteDao.delNote(note);
    }

    suspend fun getNoteByContactId(contactId: Long) : Note?{
        return noteDao.getContactId(contactId)
    }

    suspend fun getNoteIdByContactId(contactId: Long): Long? {
        return noteDao.getCont(contactId)
    }
}